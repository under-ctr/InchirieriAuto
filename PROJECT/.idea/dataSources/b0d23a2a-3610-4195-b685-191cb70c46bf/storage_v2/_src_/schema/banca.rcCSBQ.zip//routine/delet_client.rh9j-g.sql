create
    definer = root@localhost procedure delet_client(IN target_id int)
begin 
    delete from client where id = target_id;
    end;


create
    definer = root@localhost procedure get_clients()
begin
    select * from client;
    end;


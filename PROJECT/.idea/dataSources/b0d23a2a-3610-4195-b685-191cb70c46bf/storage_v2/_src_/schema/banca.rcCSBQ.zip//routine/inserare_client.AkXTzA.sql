create
    definer = root@localhost procedure inserare_client(IN id int, IN nume varchar(45), IN prenume varchar(45),
                                                       IN adresa varchar(45))
begin 
    insert into client values(id,nume,prenume,adresa);
    
    end;


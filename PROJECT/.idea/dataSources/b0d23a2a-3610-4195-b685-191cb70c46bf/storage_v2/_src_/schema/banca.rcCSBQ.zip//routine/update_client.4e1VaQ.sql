create
    definer = root@localhost procedure update_client(IN target_id int, IN new_nume varchar(45),
                                                     IN new_prenume varchar(45))
begin
    update client set nume = new_nume , prenume = new_prenume 
    where id = target_id;
    end;


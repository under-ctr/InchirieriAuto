create definer = root@localhost trigger add_cont
    after insert
    on client
    for each row
begin 
		insert into cont values(1, 0, new.id);
    end;


create
    definer = root@localhost procedure calculeaza_reducere(IN perioada int, OUT valoarea int)
begin
if perioada >= 1 and perioada <=7 then 
		set valoarea = 25;
	elseif perioada >=8  and perioada <=14 then
		set valoarea = 30;
	elseif perioada >=14 and perioada <= 21 then 
		set valoarea = 40;
	else 
		set valoarea = 50;
	end if;
end;


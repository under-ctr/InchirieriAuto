create
    definer = root@localhost procedure inserare_user(IN namee varchar(45), IN parolaa varchar(45))
begin 
declare a varchar(45); 
set a = 0;
select username into a from login where  namee = login.username; 
	if length(a) <= 2 then 
		insert into login(username, parola)	values(namee, parolaa); 
	end if;
end;


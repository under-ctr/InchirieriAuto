create
    definer = root@localhost procedure insereaza_client(IN CNP1 varchar(14), IN nume varchar(45), IN prenume varchar(45))
begin 
declare a varchar(14); 
set a = 0;
select CNP into a from client where CNP1 = client.CNP; 
    if length(a) <= 2 then 
			insert into client values(CNP1, nume, prenume);
	end if;
end;


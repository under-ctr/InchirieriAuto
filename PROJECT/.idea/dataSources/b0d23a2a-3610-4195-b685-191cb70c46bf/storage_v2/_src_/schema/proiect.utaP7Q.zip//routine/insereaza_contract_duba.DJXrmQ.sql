create
    definer = root@localhost procedure insereaza_contract_duba(IN CNP varchar(14), IN nr varchar(7), IN per int)
begin 
	insert into contract(cnp_client, perioada, nr_duba ) values( CNP , per ,nr);
end;


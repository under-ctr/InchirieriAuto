create
    definer = root@localhost procedure insereaza_contract_masina(IN CNP int, IN nr varchar(7), IN per int)
begin 
	insert into contract(cnp_client,nr_masina, perioada ) values( CNP , nr, per );
end;


create
    definer = root@localhost procedure insereaza_contract_speciala(IN CNP varchar(14), IN nr varchar(7), IN per int)
begin 
	insert into contract(cnp_client, perioada, nr_speciala ) values( CNP , per,  nr);
end;


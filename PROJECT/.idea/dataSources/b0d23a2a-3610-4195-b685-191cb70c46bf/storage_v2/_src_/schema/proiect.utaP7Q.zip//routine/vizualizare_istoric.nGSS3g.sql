create
    definer = root@localhost procedure vizualizare_istoric(IN cnp1 varchar(14))
begin 
select data_inchiriere,numar_zile, data_retur from istoric_inchirieri i where cnp1 = i.cnp; 
end;


create definer = root@localhost trigger bani_castigati
    before insert
    on contract
    for each row
begin 
	set @nr = new.nr_masina;
    select suma_produsa into @a from autoturisme  where Nr_inmatriculare = @nr ;
    set @b = new.pret_final;
    set @c = @a + @b;
	update autoturisme set suma_produsa = @c 
    where Nr_inmatriculare = @nr; 
end;


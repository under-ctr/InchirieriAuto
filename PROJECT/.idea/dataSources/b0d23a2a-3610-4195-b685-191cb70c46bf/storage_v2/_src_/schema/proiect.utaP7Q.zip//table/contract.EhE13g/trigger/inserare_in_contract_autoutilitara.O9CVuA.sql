create definer = root@localhost trigger inserare_in_contract_autoutilitara
    before insert
    on contract
    for each row
begin

set @pret = 0; 

set @nr = new.nr_duba;

if new.nr_duba = NULL then
	set new.pret_final = 0;
else
		select Pret into @pret from autoutilitare  where autoutilitare.Nr_Inmatriculare = @nr;
		call calculeaza_reducere(new.perioada, @valoare);
		set new.pret_final = (@pret - @valoare) * new.perioada; 
end if;
end;


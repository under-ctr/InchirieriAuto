create definer = root@localhost trigger inserare_in_contract_masina
    before insert
    on contract
    for each row
begin
set @pret = 0; 
set @nr = new.nr_masina; 
set @nr_duba = new.nr_duba;
set @nr_speciala = new.nr_speciala;

if length(@nr) >= 7  then
	select Pret into @pret from autoturisme  where autoturisme.Nr_Inmatriculare = @nr;
	call calculeaza_reducere(new.perioada, @valoare);
	set new.pret_final = (@pret - @valoare) * new.perioada; 
elseif length(@nr_duba) >= 7 then
		select Pret into @pret from autoutilitare  where autoutilitare.Nr_Inmatriculare = @nr_duba;
		call calculeaza_reducere(new.perioada, @valoare);
		set new.pret_final = (@pret - @valoare) * new.perioada; 
elseif  length(@nr_speciala) >= 7  then
		select Pret into @pret from evenimente_speciale  where evenimente_speciale.Nr_Inmatriculare = @nr_speciala;
		call calculeaza_reducere(new.perioada, @valoare);
		set new.pret_final = (@pret - @valoare) * new.perioada;
end if;
end;


create definer = root@localhost trigger inserare_istoric
    before insert
    on contract
    for each row
begin

set @dataa = CURDATE();
set @datafinal = DATE_ADD(@dataa, INTERVAL new.perioada day);

insert into proiect.istoric_inchirieri(CNP, data_inchiriere,numar_zile, data_retur) values (new.cnp_client, @dataa, new.perioada, @datafinal);

end;


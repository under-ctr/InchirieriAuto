create view angajat_bogat as
select `a`.`Nume` AS `Nume`, `a`.`Prenume` AS `Prenume`
from `proiect`.`angajat` `a`
where ((`a`.`Salar` > 3000) and (`a`.`Oras` = 'Vaslui'));


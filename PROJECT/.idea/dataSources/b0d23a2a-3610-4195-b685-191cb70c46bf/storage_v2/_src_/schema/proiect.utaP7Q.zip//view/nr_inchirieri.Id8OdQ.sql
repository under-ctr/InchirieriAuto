create view nr_inchirieri as
select `a`.`Marca` AS `masina`, count(`c`.`nr_masina`) AS `nr_inchirieri`
from (`proiect`.`autoturisme` `a`
         join `proiect`.`contract` `c` on ((`a`.`Nr_Inmatriculare` = `c`.`nr_masina`)))
group by `a`.`Marca`;


create view perioada_inchiriere as
select `a`.`Marca` AS `marca`, `c`.`perioada` AS `perioada`
from (`proiect`.`autoturisme` `a`
         join `proiect`.`contract` `c` on (((`a`.`Nr_Inmatriculare` = `c`.`nr_masina`) and (`c`.`perioada` > 28))));

